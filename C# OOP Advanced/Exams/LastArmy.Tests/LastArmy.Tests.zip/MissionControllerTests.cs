﻿
using NUnit.Framework;

[TestFixture]
public class MissionControllerTests
{
    private MissionController sut;
    private IArmy army;
    private IWareHouse wareHouse;

    [SetUp]
    public void TestInit()
    {
        this.army = new Army();
        this.wareHouse = new WareHouse();
        this.sut = new MissionController(army, wareHouse);
    }

    [Test]
    public void PerformMissionEnqueuesMissionCorrectly()
    {
        this.sut.PerformMission(new Easy(50));

        Assert.AreEqual(1, this.sut.Missions.Count);
    }

    [Test]
    public void PerformMissionWithoutEnoughSoldiersReturnsCorrectMessage()
    {
        var mission = new Hard(20);

        var message = this.sut.PerformMission(mission).Trim();

        Assert.AreEqual($"Mission on hold - {mission.Name}", message);
    }
}

