﻿using System;
using System.Collections.Generic;
using System.Text;
using DungeonsAndCodeWizards.Interfaces;

namespace DungeonsAndCodeWizards.Entities.Bag
{
    public class Satchel : Bag
    {
        public Satchel()
        {
            this.Capacity = 20;          
        }
    }
}
