﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using DungeonsAndCodeWizards.Interfaces;

namespace DungeonsAndCodeWizards.Entities.Bag
{
    public class Backpack : Bag
    {
        public Backpack()
        {
        }
    }
}
