﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string text);
    }
}
