﻿
public class Knife : Ammunition
{
    public const double CurrentWeight = 0.4;

    public Knife(string name)
        : base(name, CurrentWeight)
    {
    }
}
