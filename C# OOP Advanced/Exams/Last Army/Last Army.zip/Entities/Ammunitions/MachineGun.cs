﻿
public class MachineGun : Ammunition
{
    public const double CurrentWeight = 10.6;

    public MachineGun(string name)
        : base(name, CurrentWeight)
    {
    }
}
