﻿
public class RPG : Ammunition
{
    public const double CurrentWeight = 17.1;

    public RPG(string name)
        : base(name, CurrentWeight)
    {
    }
}
