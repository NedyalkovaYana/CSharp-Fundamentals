﻿
public static class OutputMessages
{
    public static string MissionSuccessful = "Mission completed - {0}";
    public static string MissionOnHold = "Mission on hold - {0}";
    public static string MissionDeclined = "Mission declined - {0}";
    public static string SoldierToString { get; set; }
}

