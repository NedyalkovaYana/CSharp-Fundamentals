﻿public class RPG : Ammunition
{
    public const double WeightValue = 17.1;

    public RPG(string name)
        : base(name, WeightValue)
    {
    }
}