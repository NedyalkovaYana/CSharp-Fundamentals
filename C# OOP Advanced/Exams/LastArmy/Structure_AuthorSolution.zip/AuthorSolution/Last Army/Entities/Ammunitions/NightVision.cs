﻿public class NightVision : Ammunition
{
    public const double WeightValue = 6.3;

    public NightVision(string name)
        : base(name, WeightValue)
    {
    }
}