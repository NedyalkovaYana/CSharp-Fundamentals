﻿public interface IGameController
{
    void ProcessCommand(string input);

    void ProduceSummury();
}
