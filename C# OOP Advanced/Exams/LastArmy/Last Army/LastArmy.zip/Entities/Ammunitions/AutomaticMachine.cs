﻿public class AutomaticMachine : Ammunition
{
    public const double ConstWeight = 6.3;

    public AutomaticMachine()
        : base(ConstWeight)
    {
    }
}