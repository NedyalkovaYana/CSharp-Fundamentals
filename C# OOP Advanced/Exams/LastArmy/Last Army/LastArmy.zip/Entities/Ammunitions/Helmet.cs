﻿
public class Helmet : Ammunition
{
    public const double ConstWeight = 2.3;

    public Helmet()
        : base(ConstWeight)
    {
    }
}
