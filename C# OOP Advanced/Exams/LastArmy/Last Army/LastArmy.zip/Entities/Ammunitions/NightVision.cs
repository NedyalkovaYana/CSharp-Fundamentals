﻿
public class NightVision : Ammunition
{
    public const double ConstWeight = 0.8;

    public NightVision()
        : base(ConstWeight)
    {
    }
}
