﻿public class Knife : Ammunition
{
    public const double ConstWeight = 0.4;

    public Knife()
        : base(ConstWeight)
    {
    }
}
