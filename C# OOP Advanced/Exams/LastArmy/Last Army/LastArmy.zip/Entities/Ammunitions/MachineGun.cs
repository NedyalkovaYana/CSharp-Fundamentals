﻿
public class MachineGun : Ammunition
{
    public const double ConstWeight = 10.6;

    public MachineGun()
        : base(ConstWeight)
    {
    }
}
