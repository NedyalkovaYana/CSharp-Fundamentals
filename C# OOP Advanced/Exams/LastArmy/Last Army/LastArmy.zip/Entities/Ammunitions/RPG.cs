﻿
public class RPG : Ammunition
{
    public const double ConstWeight = 17.1;

    public RPG()
        : base(ConstWeight)
    {
    }
}
