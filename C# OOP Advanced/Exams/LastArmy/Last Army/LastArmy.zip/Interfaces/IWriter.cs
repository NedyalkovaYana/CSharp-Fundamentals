﻿
public interface IWriter
{
    void WriteLine(string output);
    void StoreMessages(string inputText);
    string StoredMessages();
}

