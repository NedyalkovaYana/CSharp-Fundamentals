﻿
public interface ISoldierController
{
}

