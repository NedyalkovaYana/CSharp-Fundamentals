﻿
using System.Collections.Generic;
public class ComparerAge : IComparer<Person>
{
    public int Compare(Person x, Person y)
    {
        return x.Age.CompareTo(y.Age);
    }
}

