﻿
public interface IWriter
{
    void WriteLine(string text);
}

