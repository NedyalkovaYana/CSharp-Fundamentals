﻿using System.Collections.Generic;
public class BookComparator : IComparer<Book>
{
    public int Compare(Book x, Book y)
    {
        int comape = x.Title.CompareTo(y.Title);

        if (comape == 0)
        {
            comape = x.Year.CompareTo(y.Year);
        }

        return comape;
    }
}

