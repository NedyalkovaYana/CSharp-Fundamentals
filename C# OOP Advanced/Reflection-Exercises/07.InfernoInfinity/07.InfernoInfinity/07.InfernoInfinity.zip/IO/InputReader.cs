﻿
using System;

public class InputReader
{
    public string ReadLine() => Console.ReadLine();
}

