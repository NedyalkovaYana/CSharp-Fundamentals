﻿
using System;

public class OutputWriter
{
    public void WriteLine(string text) => Console.WriteLine(text);
}

