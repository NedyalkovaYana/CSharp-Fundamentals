﻿using System;

namespace _07.InfernoInfinity
{
    public class StartUp
    {
        public static void Main()
        {
            new Engine().Run();
        }
    }
}
