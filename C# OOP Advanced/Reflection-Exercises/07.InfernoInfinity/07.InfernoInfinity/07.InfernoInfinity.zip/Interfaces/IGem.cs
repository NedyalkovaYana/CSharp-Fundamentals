﻿
public interface IGem
{
    GemClarity Clarity { get; }
    int StrenghtBonus { get; }
    int AgilityBonus { get; }
    int VatilityBonus { get; }
}

