﻿namespace P03_BarraksWars.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
