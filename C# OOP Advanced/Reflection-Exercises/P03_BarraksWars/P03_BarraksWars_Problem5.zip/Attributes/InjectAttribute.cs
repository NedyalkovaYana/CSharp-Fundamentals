﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_BarraksWars.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
   public class InjectAttribute : Attribute
    {

    }
}
