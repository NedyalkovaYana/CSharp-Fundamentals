﻿namespace P03_BarraksWars.Contracts
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
