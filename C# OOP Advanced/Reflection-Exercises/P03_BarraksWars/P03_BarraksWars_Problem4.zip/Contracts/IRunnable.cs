﻿namespace P03_BarraksWars.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
