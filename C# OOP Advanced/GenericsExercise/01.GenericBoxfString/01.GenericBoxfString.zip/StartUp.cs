﻿using System;

public class StartUp
{
    public static void Main()
    {
         //Manager.GenericBox();
         //Manager.CenericBoxOfString();
         //Manager.GenericBoxOfInteger();
        // Manager.SwapMethodStrings();
        // Manager.SwapMethodOfIntegers();
         //Manager.GenericCountMethodStrings();
        Manager.GenericCountMethodDoubles();
    }
}

