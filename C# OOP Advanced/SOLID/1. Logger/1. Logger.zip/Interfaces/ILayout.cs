﻿public  interface ILayout
{
    //string ReportFormat(string dateTime, string reportLevel, string message);
    string FormatMessage(string dateTime, string reportLevel, string s);
}

