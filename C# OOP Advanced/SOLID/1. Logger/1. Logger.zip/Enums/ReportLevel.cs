﻿public enum ReportLevel
{
    Info,
    Warn, 
    Error, 
    Critical,
    Fatal
}

