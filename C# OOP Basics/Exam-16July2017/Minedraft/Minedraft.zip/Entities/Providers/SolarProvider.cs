﻿public class SolarProvider : Provider
{
    //Extracts energy from the Sun. Nothing special here.
    public SolarProvider(string id, double energyOutput)
        : base(id, energyOutput)
    {
    }
}

