﻿public class Citizen : ICitizen
{
    public Citizen(string name, int age, string id, string birthday) 
        : base(name, age, id, birthday)
    {
    }
}

