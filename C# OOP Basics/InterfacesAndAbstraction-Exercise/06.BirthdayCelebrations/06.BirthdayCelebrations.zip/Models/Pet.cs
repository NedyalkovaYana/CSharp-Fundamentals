﻿public class Pet : IPet
{
    public Pet(string name, string birthday) 
        : base(name, birthday)
    {
    }
}

