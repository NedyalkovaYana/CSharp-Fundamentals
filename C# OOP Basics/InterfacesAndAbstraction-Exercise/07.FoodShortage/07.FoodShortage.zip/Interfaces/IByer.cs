﻿public interface IByer
{
    string Name { get; }
    int Food { get; }
    void BuyFood();
}

