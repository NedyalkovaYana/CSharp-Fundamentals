﻿public interface ICitizen : IIdable
{
    string Name { get; }
    int Age { get; }
}

