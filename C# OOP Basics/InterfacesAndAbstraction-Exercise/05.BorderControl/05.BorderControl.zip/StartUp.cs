﻿using System;
using System.Collections;
using System.Collections.Generic;

public class StartUp
{
    public static void Main()
    {
        List<string> townPopulation = new List<string>();
        var citizens = new List<Citizen>();
        var robots = new List<Robot>();
        var inputData = string.Empty;

        while ((inputData = Console.ReadLine()) != "End")
        {
            var tokens = inputData.Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries);
            if (tokens.Length == 3)
            {
                var personName = tokens[0];
                var age = int.Parse(tokens[1]);
                var personId = tokens[2];
                var person = new Citizen(personId, personName, age);
                citizens.Add(person);
                townPopulation.Add(person.Id);
            }
            else
            {
                var model = tokens[0];
                var robotId = tokens[1];
                var robot = new Robot(robotId, model);
                robots.Add(robot);
                townPopulation.Add(robot.Id);
            }
        }

        var detainedCitizens = new List<Citizen>();
        var end = Console.ReadLine();
        List<Object> detained = new List<object>();
        foreach (var p in townPopulation)
        {
            if (p.EndsWith(end))
            {
                detained.Add(p);
            }          
        }
        foreach (var d in detained)
        {
            Console.WriteLine(d);
        }




        //foreach (var citizen in citizens)
        //{
        //    if (citizen.Id.EndsWith(end))
        //    {
        //        detainedCitizens.Add(citizen);
        //    }
        //}

        //var detainedRobots = new List<Robot>();
        //foreach (var robot in robots)
        //{
        //    if (robot.Id.EndsWith(end))
        //    {
        //        detainedRobots.Add(robot);
        //    }
        //}

        //foreach (var c in detainedCitizens)
        //{
        //    Console.WriteLine(c.Id);
        //}
        //foreach (var r in detainedRobots)
        //{
        //    Console.WriteLine(r.Id);
        //}
    }
}

