﻿public interface ICar
{
    string Name { get; }
    string Start();
    string Stop();
}

