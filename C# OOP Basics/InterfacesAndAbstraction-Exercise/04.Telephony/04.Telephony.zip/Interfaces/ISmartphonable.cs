﻿public interface ISmartphonable : IPhonable
{
    string Browse(string url);
}

