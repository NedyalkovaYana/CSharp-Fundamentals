﻿public interface ISolider
{
    string Id { get; }
    string FirstName { get; }
    string LastName { get; }

}
