﻿public interface ISpy : ISolider
{
    int CodeNumber { get; }
}

