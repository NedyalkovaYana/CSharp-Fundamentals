﻿public interface IPrivate : ISolider
{
    double Salary { get; }
}

