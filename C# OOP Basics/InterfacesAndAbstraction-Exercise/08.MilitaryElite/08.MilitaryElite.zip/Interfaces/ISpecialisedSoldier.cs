﻿public interface ISpecialisedSoldier : IPrivate
{
    string Crops { get; }
}

