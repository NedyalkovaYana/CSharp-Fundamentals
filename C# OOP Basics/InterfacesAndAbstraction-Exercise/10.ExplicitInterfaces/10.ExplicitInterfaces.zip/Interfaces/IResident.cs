﻿public interface IResident : IPerson
{
    string Country { get; }
    void GetName();
}

