﻿public interface IAnimals
{
    string Name { get; }
    string FavoriteFood { get; }

}

