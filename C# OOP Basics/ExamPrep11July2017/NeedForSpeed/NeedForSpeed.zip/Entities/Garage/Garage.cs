﻿using System.Collections.Generic;

class Garage
{
    public List<int> parkedCars = new List<int>();

}

