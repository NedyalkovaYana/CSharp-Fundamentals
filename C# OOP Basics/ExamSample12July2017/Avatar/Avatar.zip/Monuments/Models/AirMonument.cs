﻿public class AirMonument : Monument
{
    private int airAffinity;

    public int AirAffinity
    {
        get { return airAffinity; }
       protected set { airAffinity = value; }
    }
    public AirMonument(string name) 
        : base(name)
    {
        this.AirAffinity = airAffinity;
    }
}

