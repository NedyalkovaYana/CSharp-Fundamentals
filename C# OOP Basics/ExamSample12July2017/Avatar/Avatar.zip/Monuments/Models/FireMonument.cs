﻿public class FireMonument : Monument
{
    private int fireAffinity;

    public int FireAffinity
    {
        get { return fireAffinity; }
        set { fireAffinity = value; }
    }

    public FireMonument(string name) 
        : base(name)
    {
        this.FireAffinity = fireAffinity;
    }
}

