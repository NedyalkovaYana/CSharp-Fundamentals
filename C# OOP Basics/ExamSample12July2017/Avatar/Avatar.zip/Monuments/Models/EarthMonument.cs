﻿public class EarthMonument : Monument
{
    private int earthAffinity;

    public int EarthAffinity
    {
        get { return earthAffinity; }
        set { earthAffinity = value; }
    }

    public EarthMonument(string name) 
        : base(name)
    {
        this.EarthAffinity = earthAffinity;
    }
}

