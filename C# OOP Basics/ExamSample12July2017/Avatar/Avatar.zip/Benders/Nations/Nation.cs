﻿using System.Collections.Generic;

public class Nation
{
    public List<FireBender> FireNation { get; set; }
    public List<AirBender> AirNation { get; set; }
    public List<EarthBender> EarthNation { get; set; }
    public List<WaterBender> WaterNation { get; set; }

    public Nation()
    {
        this.FireNation = new List<FireBender>();
        this.AirNation = new List<AirBender>();
        this.EarthNation = new List<EarthBender>();
        this.WaterNation = new List<WaterBender>();
    }

    public void AddFireMember(FireBender fireBender)
    {
        this.FireNation.Add(fireBender);
    }
    public void AddFAirMember(AirBender airBender)
    {
        this.AirNation.Add(airBender);
    }
    public void AddEarthMember(EarthBender earthBender)
    {
        this.EarthNation.Add(earthBender);
    }
    public void AddWaterMember(WaterBender waterBender)
    {
        this.WaterNation.Add(waterBender);
    }

}

