﻿public class WaterBender : Bender
{
    private double waterClarity;

    public double WaterClarity
    {
        get { return waterClarity; }
        protected set { waterClarity = value; }
    }

    public WaterBender(string name, int power) 
        : base(name, power)
    {
        this.WaterClarity = waterClarity;
    }
}

