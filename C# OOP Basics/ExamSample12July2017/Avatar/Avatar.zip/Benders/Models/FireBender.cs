﻿public class FireBender : Bender
{
    private double heatAggression;

    public double HeatAggression
    {
        get { return heatAggression; }
        set { heatAggression = value; }
    }


    public FireBender(string name, int power) 
        : base(name, power)
    {
        this.HeatAggression = heatAggression;
    }
}

