﻿public abstract class Center : IMinder
{
    protected Center(string name) 
        : base(name)
    {
    }

    public virtual void Cleanse()
    {
        
    }
}

