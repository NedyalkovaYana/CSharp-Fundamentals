﻿public class AdoptionCenter : Center
{
    public AdoptionCenter(string name) 
        : base(name)
    {
    }
}

