﻿public class CleansingCenter : Center
{
    public CleansingCenter(string name) 
        : base(name)
    {
    }
}

