﻿public class CastrationCenter : IMinder
{
    public CastrationCenter(string name)
        : base(name)
    {
    }
}

