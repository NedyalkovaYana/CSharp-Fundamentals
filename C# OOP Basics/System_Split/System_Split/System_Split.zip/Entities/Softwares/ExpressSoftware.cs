﻿public  class ExpressSoftware : Software
{
    public ExpressSoftware(string type, int capacityConsumption, int memoryConsumption) 
        : base("Express", type, capacityConsumption, memoryConsumption)
    {
        this.MemoryConsumption *= 2;

    }
}

