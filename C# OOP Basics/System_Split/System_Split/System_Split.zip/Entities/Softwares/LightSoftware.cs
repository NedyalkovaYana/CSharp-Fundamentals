﻿public class LightSoftware : Software
{
    public LightSoftware(string type, int capacityConsumption, int memoryConsumption) 
        : base("Light", type, capacityConsumption, memoryConsumption)
    {
        this.CapacityConsumption += (capacityConsumption * 50) / 100;
        this.MemoryConsumption -= (memoryConsumption * 50) / 100;
    }
}

