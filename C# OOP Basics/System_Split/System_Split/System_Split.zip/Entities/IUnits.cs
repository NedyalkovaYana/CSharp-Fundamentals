﻿public interface IUnits
{
    string Name { get; }
    string Type { get; }
}

