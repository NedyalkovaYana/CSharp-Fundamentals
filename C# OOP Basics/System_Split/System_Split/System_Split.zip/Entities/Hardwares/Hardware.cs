﻿public abstract class Hardware : IUnits
{
    protected Hardware(string name, string type, int maxCapacity, int maxMemory)
    {      
        this.Name = name;
        this.Type = type;
        this.MaxCapacity = maxCapacity;
        this.MaxMemory = maxMemory;
    }

    public int MaxCapacity { get; protected set; }
    public int MaxMemory { get; protected set; }
    public string Name { get; }
    public string Type { get; }
}

