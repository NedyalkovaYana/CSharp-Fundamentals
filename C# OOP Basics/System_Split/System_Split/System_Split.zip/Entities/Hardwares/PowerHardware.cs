﻿public class PowerHardware : Hardware
{
    public PowerHardware(string type, int maxCapacity, int maxMemory) 
        : base("Power", type, maxCapacity, maxMemory)
    {
        this.MaxCapacity -= (maxCapacity * 75)/100;
        this.MaxMemory += (maxCapacity * 75) / 100;
    }
}

