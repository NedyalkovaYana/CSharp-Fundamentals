﻿public class HeavyHardware : Hardware
{
    public HeavyHardware(string type, int maxCapacity, int maxMemory) 
        : base("Heavy", type, maxCapacity, maxMemory)
    {
        this.MaxMemory -= (maxMemory * 25) / 100;
        this.MaxCapacity *= 2;
    }
}

