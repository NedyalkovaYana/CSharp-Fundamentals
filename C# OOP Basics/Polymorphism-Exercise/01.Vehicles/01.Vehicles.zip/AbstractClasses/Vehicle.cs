﻿public abstract class Vehicle : IVehicle
{  
    public double FuelQuantity { get; protected set; }
    public double FuelConsumation { get; protected set; }

    protected Vehicle(double fuelQuantity, double fuelConsumation)
    {
        FuelQuantity = fuelQuantity;
        FuelConsumation = fuelConsumation;
    }

    public virtual string Drive()
    {
        return "Drive";
    }

    public virtual void Refueled()
    {       
    }
}

