﻿public interface IVehicle
{
    double FuelQuantity { get; }
    double FuelConsumation { get; }
    string Drive();
    void Refueled();
}

