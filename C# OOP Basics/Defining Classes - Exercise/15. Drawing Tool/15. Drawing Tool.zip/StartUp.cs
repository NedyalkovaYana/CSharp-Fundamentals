﻿using System;

public class Program
{
    public static void Main()
    {
        var inputShape = Console.ReadLine();
        if (inputShape == "Square")
        {
            var n = int.Parse(Console.ReadLine());

            Console.WriteLine($"|{new string('-', n)}|");
            for (int i = 0; i < n - 2; i++)
            {
                Console.WriteLine($"|{new string(' ', n)}|");
            }
            Console.WriteLine($"|{new string('-', n)}|");
        }
        else
        {
            var height = int.Parse(Console.ReadLine());
            var wight = int.Parse(Console.ReadLine());

            Console.WriteLine($"|{new string('-', height)}|");
            for (int i = 0; i < wight - 2; i++)
            {
                Console.WriteLine($"|{new string(' ', height)}|");
            }
            Console.WriteLine($"|{new string('-', height)}|");
        }
    }
}

